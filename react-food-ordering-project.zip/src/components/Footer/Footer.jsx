import React from "react";
import "./Footer.css";
import { assets } from "../../assets/assets";
import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <div className="footer" id="footer">
      <div className="footer-content">
        <div className="footer-content-left">
          <a href="#home">
            <img className="foot-img" src={assets.logo} alt="" />
          </a>
          <p>
            Lorem ipsum, dolor sit amet consectetur adipisicing elit. Non hic
            doloremque numquam vel fugiat reiciendis architecto in vero,
            accusantium qui magni nemo accusamus ut. , ducimus quo voluptas
            distinctio. Nihil illo inventore optio qui!
          </p>
          <div className="footer-social-icons">
            <img src={assets.facebook_icon} alt="" />
            <img src={assets.twitter_icon} alt="" />
            <img src={assets.linkedin_icon} alt="" />
          </div>
        </div>
        <div className="footer-content-center">
          <h2>COMPANY</h2>
          <ul>
            <Link to="/">
              <li>Home</li>
            </Link>
            <li>About Us</li>
            <li>Delivery</li>
            <li>Privacy Policy</li>
          </ul>
        </div>
        <div className="footer-content-right">
          <h2 className="fcrh">Get in Touch</h2>
          <ul>
            <li>+91-7986401732</li>
            <li>vishwasnaidu26@gmail.com</li>
          </ul>
        </div>
      </div>
      <hr />
      <p className="footer-copyright">
        Copyright &copy; tasteconcept.com - All Rights Reserved.
      </p>
    </div>
  );
};

export default Footer;
