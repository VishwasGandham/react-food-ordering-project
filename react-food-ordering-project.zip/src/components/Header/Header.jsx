import React from "react";
import "./Header.css";

const Header = () => {
  return (
    <div className="header">
      <div className="header-contents">
        <h2>Order your favourite food here</h2>
        <p>
          Indulge in a diverse selection of dishes, carefully crafted to satisfy
          every craving. Whether you're seeking bold flavors or comforting
          classics, our menu is designed to elevate your dining experience and
          leave you delighted with every bite.
        </p>
        <a href="#explore-menu">
          <button>View Menu</button>
        </a>
      </div>
    </div>
  );
};

export default Header;
